﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceForTransport
{
    class PriceForTransport
    {
        static void Main(string[] args)
        {
            var kilometers = int.Parse(Console.ReadLine());
            string dayPeriod = Console.ReadLine();

            var startChargeForTaxi = 0.70;
            var dayCostForTaxi = 0.79;
            var nightCostForTaxi = 0.90;

            var busPricePerKilometer = 0.09;

            var trainPricePerKilometer = 0.06;

            var totalPrice = 0D;

            if(kilometers < 20)
            {
                totalPrice = totalPrice + startChargeForTaxi;

                if(dayPeriod == "day")
                {
                    totalPrice = totalPrice + ( kilometers * dayCostForTaxi );
                }
                else
                {
                    totalPrice = totalPrice + ( kilometers * nightCostForTaxi );
                }
            }
            else if(kilometers >= 20 && kilometers < 100)
            {
                totalPrice = kilometers * busPricePerKilometer;
            }
            else
            {
                totalPrice = kilometers * trainPricePerKilometer;
            }

            Console.WriteLine(totalPrice);
        }
    }
}
