﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimePlus15
{
    class TimePlus
    {
        static void Main(string[] args)
        {

            //Console.WriteLine(63 / 60);
           var hours = int.Parse(Console.ReadLine());
           var minutes = int.Parse(Console.ReadLine());
           var minutesToAdd = 15;
           //
           ////TimeSpan mySpan = new TimeSpan(hours , minutes + minutesToAdd , 0);
           //
           ////Console.WriteLine("{0}:{1:00}" , mySpan.Hours , mySpan.Minutes);
           //
           minutes = minutes + minutesToAdd;
           var totalMinutes = minutes % 60;
            hours = hours + minutes / 60;



            Console.WriteLine("{0}:{1:00}", hours % 24, totalMinutes);
        }
    }
}
