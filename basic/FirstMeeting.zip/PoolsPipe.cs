﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoolsPipe
{
    class PoolsPipe
    {
        static void Main(string[] args)
        {
            var volume = int.Parse(Console.ReadLine());
            var firstPipeDebit = int.Parse(Console.ReadLine());
            var secondPipeDebit = int.Parse(Console.ReadLine());
            var hours = double.Parse(Console.ReadLine());

            var firstPipeVolume = firstPipeDebit*hours;
            var secondPipeVolume = secondPipeDebit*hours;
            var totalPipesVolume = firstPipeVolume + secondPipeVolume;

            if (volume < totalPipesVolume)
            {
                Console.WriteLine("For {0} hours the pool overflows with {1} liters.", hours, totalPipesVolume - volume);
            }
            else
            {
                var volumePercentageFull = (int)((totalPipesVolume*100.0)/volume);
                var firstPipePercentage = (int)((firstPipeVolume*100)/totalPipesVolume);
                var secondPipePercentage = Math.Truncate((secondPipeVolume*100)/totalPipesVolume);
                Console.WriteLine("The pool is {0}% full. Pipe 1: {1}%. Pipe 2: {2}%.", volumePercentageFull, firstPipePercentage, secondPipePercentage );
            }
        }
    }
}
